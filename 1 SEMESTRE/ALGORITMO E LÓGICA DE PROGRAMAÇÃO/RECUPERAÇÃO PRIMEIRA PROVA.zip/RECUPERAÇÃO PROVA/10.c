#include <stdio.h>

int main()
{
    int n = 0, soma = 0, qtd = 0;

    do
    {

       printf("Digite um número inteiro positivo: ");
       scanf("%d", &n);

        if (n==0)
        {
            break;
        }
        soma += n;
        qtd++;

    } while (n != 0);

    printf("A soma dos valores é: %d \n", soma);

    printf("A quantidade de valores digitados foi: %d \n", qtd);
    
}