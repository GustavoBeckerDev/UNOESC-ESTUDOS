#include <stdio.h>

int main()
{
    int i = 0, n = 0, pares = 0, impares = 0, somapar = 0;
    float media = 0;

    for (i=0; i< 10; i++)
    {

       printf("Digite o %d numero: ", i+1);
       scanf("%d", &n);

        if (n % 2 == 0)
        {
            pares++;
            somapar += n;
        } else {
            impares++;
        }

        media +=n;

    } 

    printf("A soma de pares e: %d \n", pares);
    printf("A soma de impares e: %d \n", impares);
    printf("A qsoma dos pares e: %d \n", somapar);
    
    media = media / 10;
    
    printf("A media dos valores e: %.2f \n", media);
}