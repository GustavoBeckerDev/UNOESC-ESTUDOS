#include <stdio.h>

int main()
{

    int i = 10, j = 0, soma = 0;

    do 
    {
        i-=2;
        soma += i + j;
        j++;

    } while (i >= 2);

    printf("Soma = %d", soma);

}